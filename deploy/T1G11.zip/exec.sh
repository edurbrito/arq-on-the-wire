gcc sender.c sframe.c iframe.c datalink.c utils.c -o sender.o
gcc receiver.c sframe.c iframe.c datalink.c utils.c -o receiver.o