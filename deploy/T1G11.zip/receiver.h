
#ifndef RECEIVER_H
#define RECEIVER_H

/**
 * Receiver main function
 * @param argc
 * @param argv
*/
int main(int argc, char **argv);

#endif