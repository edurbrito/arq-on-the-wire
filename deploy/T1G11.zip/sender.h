
#ifndef SENDER_H
#define SENDER_H

/**
 * Sender main function
 * @param argc
 * @param argv
*/
int main(int argc, char **argv);

#endif